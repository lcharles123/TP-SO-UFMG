#!/bin/sh

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$PWD
export PATH=$PATH:$PWD
# se der o erro " error while loading shared libraries: libvirglrenderer.so.1"; entao adicionar /usr/lib/x86_64-linux-gnu
# em /etc/ld.so.conf.d/x86_64-linux-gnu.conf

qemu-system-x86_64 $0 

